export default [
    {title: '首页',icon: 'iconshouye1', path: '/home', name: 'home', component: 'Home'},
    {title: '企业管理',icon: 'iconqiye', path: '/testA', name: 'testA', component: 'testA'},
    {title: '财务管理',icon: 'iconcaiwu', path: '/testB', name: 'testB', component: 'testB'},
    {title: '产品管理',icon: 'iconcaiwu', path: '/testC', name: 'testC', component: 'testC'},
    {title: '企业管理',icon: 'iconManage', path: '/testD', name: 'testD', component: 'testD'},
    {title: '角色管理',icon: 'iconRole', path: '/testE', name: 'testE', component: 'testE'},
    {title: '产品管理',icon: 'iconProduct', path: '/testF', name: 'testF', component: 'testF'},
  ]