const state = {
    parking_type_json: {
        1: {label: '室内', value: 1},
        2: {label: '室外', value: 2}
    }
}