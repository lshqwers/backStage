<template>
    <div class="layout-container" style="width: auto">
        <el-container class="layout-container">
            <el-aside width="auto" hight="auto">
                <!--  <Common_aside  :isCollapse="isCollapse" /> -->
                <CommonAside  :isCollapse="isCollapse" />
            </el-aside>
            <el-container>
                    <el-header>
                      <ComponentsHeader @childChange1="childChange"/>
                    </el-header>
                    <el-main>
                      <!-- Main -->
                      <!-- <router-view /> -->
                      <router-view/>
                    </el-main>
                    <el-footer>Footer</el-footer>
            </el-container>
        </el-container>
    </div>
</template>

<script>
// home页面可以为公共的layout，而不是首页这种的说法,所有的菜单跳转都有菜单的导航区域, 顶部的header区域
import CommonAside from '../components/commonAside.vue';
import ComponentsHeader from '@/components/header';
export default {
    name: 'Home',
    components: {
        CommonAside,
        ComponentsHeader
    },
    data(){
        return {
          isCollapse: false
        }
    },
    methods: {
      childChange(val){
        this.isCollapse = !val
        console.log(val, 'valqew', !val)
      }
    }
}
</script>

<style lang="less" scoped>
.layout-container {
  height: 100%;
//   background: #545c64
}
// .el-container{
//     // width: 100%;
//     height: 100%;
// }
.el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
    background: #333;
  }
  
  .el-aside {
    background-color: #545c64;
    color: #333;
    text-align: center;
    // line-height: 200px;
    height: auto;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    // text-align: center;
    // line-height: 160px; 可能会导致表头高度变长
  }
  
//   body > .el-container {
//     margin-bottom: 40px;
//     height: 100%;
//   }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>