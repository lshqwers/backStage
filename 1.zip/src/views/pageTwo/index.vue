<template>
    <div>
        page2
    </div>
</template>

<script>
export default {
    name: 'Page'
}
</script>

<style>

</style>