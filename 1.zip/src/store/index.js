import Vue from 'vue'
import Vuex from 'vuex'
import tab from './tab'
// Vuex全局注入
Vue.use(Vuex)
// 把Store对外界进行暴露
export default new Vuex.Store({
  state: {
    // tab
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  // modules的方式将不同的模块进行引入
  modules: {
    tab
  }
})
