# backstage

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```
cnpm install axios -s

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

// 使用element的按需导入
1.npm install babel-plugin-component -D
在babel.config.js文件中引入下面的代码
2.将.babelrc 修改为：
{
  "presets": [["es2015", { "modules": false }]],
  "plugins": [
    [
      "component",
      {
        "libraryName": "element-ui",
        "styleLibraryName": "theme-chalk"
      }
    ]
  ]
}

// 单应用
下载了路由,
要在main.js中
需要注册和挂载

下载less
npm i less
下载less的解析器
npm i less-loader@5.0.0
<style lang="less" scoped>
</style>
启动项目

npm install less less-loader --save-dev
https://www.jianshu.com/p/a17c8736f985

要使用vuex需要在main.js中引入
如果pageage.json中文件,沒有vuex则需要下載 npm i vuex

在main.js中引入
import store from './store'
在项目的src文件下创建一个store文件
store管理vuex中的一些配置
store.js
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})

// 点击勾选后,table当前行为蓝色
勾选当前行变为
forEach和map是不能return出去, 因为勾选当前行要退出, 所以可以使用for来终止循环
map和forEach是不能终止循环的, try catch可以使用
https://www.jb51.net/article/169043.htm

// 路由的权限的业务
1. 定义好全部的路由地址
2.通过用户不同像后台请求不同的用户权限数据
3.对用户权限做对比: 请求数据 === 全部的路由 取出来作为路由的配置

// 根据路由的权限不同, 看到的路由结构不同

components是放的公共组件
// 不能让一个标签中使用v-if或者v-for
<!-- <li v-for v-if></li> -->


可以多选的下拉菜单，带输入的对话框，日期选择器等等，于是我们会想办法将这些共有的功能抽取成一个个公共组件，以便能够在不同的页面或业务中使用。